﻿using DialogDemo.Models;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

namespace DialogDemo.Views.Dialogs
{
    /// <summary>
    /// Lógica de interacción para PersonSelectorDialog.xaml
    /// </summary>
    public partial class PersonSelectorDialog : Window, INotifyPropertyChanged
    {
        private PersonaCollection _personas = new PersonaCollection();
        public PersonaCollection Personas
        {
            get { return _personas; }
            set 
            { 
                _personas = value;
                lbx_personas.ItemsSource = value;
                RaisePropertyChanged("Personas");
            }
        }

        public Persona SelectedPersona
        {
            get { return (Persona)lbx_personas.SelectedItem; }
        }

        public PersonSelectorDialog(PersonaCollection lista)
        {
            InitializeComponent();
            Personas = lista;
        }

        #region Ejemplo descarga de usuarios async
        private void DescargarUsuarios()
        {
            //Task t = Task.Run(async () =>
            //{
            //    try
            //    {
            //        Personas = await Task.Run(() => App.DbConnector.ListarUsuarios());
            //        Application.Current.Dispatcher.Invoke(new Action(() =>
            //        {
            //            lbx_personas.ItemsSource = Personas;
            //        }));
                    
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("Error sincronizando comentarios: " + ex.ToString());
            //    }      
            //});
        }
        #endregion

        private void bt_ok_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void window_main_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }

        private void lbx_personas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (lbx_personas.SelectedIndex > -1 && lbx_personas.SelectedItem != null)
            {
                DialogResult = true;
            }
        }


        #region Implementación de INotifyPropertyChanged
        protected void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}