﻿using DialogDemo.Models;
using System;
using System.Windows;
using System.Windows.Controls;

namespace DialogDemo.Views.Dialogs
{
    /// <summary>
    /// Lógica de interacción para TextBoxInputDialog.xaml
    /// </summary>
    public partial class TextBoxInputDialog : Window
    {
        public string ResponseText
        {
            get { return tx_nombre.Text.Trim(); }
            set { tx_nombre.Text = value.Trim(); }
        }

        public TextBoxInputDialog(Persona _persona)
        {
            InitializeComponent();
            ResponseText  = _persona.Nombre;
        }

        private void OKButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            ResponseText = tx_nombre.Text.Trim();
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
      
    }
}
