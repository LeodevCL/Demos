﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace DialogDemo.Models
{
    public class PersonaCollection : ObservableCollection<Persona>
    {

    }

    public class Persona : Implementaciones
    {
        private string _dni;
        public string Dni
        {
            get { return _dni; }
            set 
            {
                _dni = value;
                RaisePropertyChanged("Dni");
            }
        }

        private string _nombre;
        public string Nombre
        {
            get { return _nombre; }
            set
            { 
                _nombre = value;
                RaisePropertyChanged("Nombre");
            }
        }

        private DateTime _fechaNacimiento;
        public DateTime FechaNacimiento
        {
            get { return _fechaNacimiento; }
            set 
            {
                _fechaNacimiento = value;
                RaisePropertyChanged("FechaNacimiento");
            }
        }

        public Persona(string _dni, string _nombre, DateTime _fechaNacimiento)
        {
            Dni = _dni;
            Nombre = _nombre;
            FechaNacimiento = _fechaNacimiento;
        }

        public override string ToString()
        {
            return Dni + " - " + Nombre;
        } 
    }
}
