﻿using DialogDemo.Models;
using DialogDemo.Views.Dialogs;
using System;
using System.Windows.Input;

namespace DialogDemo.ViewModels
{
    public class MainViewModel : Implementaciones
    {

        private PersonaCollection _listaPersonas = new PersonaCollection()
        {
            new Persona("11112222", "Juan Rodriguez Lara", new DateTime(1980, 12, 04)),
            new Persona("33334444", "Luisa Godoy Montalva", new DateTime(1976, 09, 16)),
            new Persona("55556666", "Rodrigo Salgado Lopez", new DateTime(1990, 07, 21))
        };

        public PersonaCollection ListaPersonas
        {
            get { return _listaPersonas; }
            set { _listaPersonas = value; }
        }

        private Persona _currentPersona;
        public Persona CurrentPersona
        {
            get { return _currentPersona; }
            set
            { 
                _currentPersona = value;
                RaisePropertyChanged("CurrentPersona");
            }
        }

        private ICommand _listarPersonasCommand;
        public ICommand ListarPersonasCommand
        {
            get
            {
                if (_listarPersonasCommand == null)
                    _listarPersonasCommand = new RelayCommand(new Action(ListarPersonas));
                return _listarPersonasCommand;
            }
        }

        private ICommand _editarNombreCommand;
        public ICommand EditarNombreCommand
        {
            get
            {
                if (_editarNombreCommand == null)
                    _editarNombreCommand = new RelayCommand(new Action(EditarNombre));
                return _editarNombreCommand;
            }
        }

        private void ListarPersonas()
        {
            var dialog = new PersonSelectorDialog(ListaPersonas);
            if (dialog.ShowDialog().Value)
            {
                if (dialog.SelectedPersona != null)
                {
                    CurrentPersona = dialog.SelectedPersona;
                }
            }
        }

        private void EditarNombre()
        {
            var dialog = new TextBoxInputDialog(CurrentPersona);
            if (dialog.ShowDialog().Value)
            {
                if (!dialog.ResponseText.Equals(null))
                {
                    CurrentPersona.Nombre = dialog.ResponseText;
                }
            }
        }




    }
}
